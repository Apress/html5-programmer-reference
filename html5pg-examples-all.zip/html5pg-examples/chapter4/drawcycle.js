/**
 * Creates a draw cycle object that will repetitively draw animation functions.
 * @constructor
 * @returns {Object} A new draw cycle object. 
 */
var DrawCycle = function() {
  var newCycle = {
    /**
     * The identifier for the current animation frame loop.
     * @type {Number} 
     */
    animationPointer: null,

    /**
     * @type {Boolean} 
     */
    isPaused: false,

    /**
     * The array of animation callbacks.
     * @type {!Array.<Function>} 
     */
    arrCallbacks: [],

    /**
     * Starts the animation cycle.
     */
    startAnimation: function() {
      newCycle.animationPointer = window.requestAnimationFrame(this.draw);
    },

    /**
     * Stops the animation cycle. 
     */
    stopAnimation: function() {
      window.cancelAnimationFrame(this.animationPointer);
    },

    /**
     * Pauses the invocation of the animation functions each draw cycle. If set
     * to true, the animation functions will not be invoked. If set to false, 
     * the functions will be invoked.
     * @type {Boolean} 
     */
    pauseAnimation: function(boolPause) {
      newCycle.isPaused = boolPause;
    },

    /**
     * Adds an animation function to the draw cycle.
     * @param {Function} 
     */
    addAnimation: function(callback) {
      if (newCycle.arrCallbacks.indexOf(callback) == -1) {
        newCycle.arrCallbacks.push(callback);
      }
    },

    /**
     * Removes an animation function from the draw cycle.
     * @param {Function} 
     */
    removeAnimation: function(callback) {
      var targetIndex = newCycle.arrCallbacks.indexOf(callback);
      if (targetIndex > -1) {
        newCycle.arrCallbacks.splice(targetIndex, 1);
      }
    },

    /**
     * Draws any registered animation functions (assuming they are not paused)
     * and then kicks off another animation cycle.
     * This is a 'private' method that you should not have to access directly.
     * @private 
     */
    draw: function() {
      if (!newCycle.isPaused) {
        var i = 0, arrCallbacksLength = newCycle.arrCallbacks.length;
        for (i = 0; i < arrCallbacksLength; i++) {
          newCycle.arrCallbacks[i]();
        }
      }
      newCycle.startAnimation();
    }
  };
  return newCycle;
};