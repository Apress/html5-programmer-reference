/**
 * Creates a draw cycle object that will repetitively draw animation functions.
 * @constructor
 * @returns {Object} A new draw cycle object. 
 */
var DrawCycle = function() {
  /**
   * The identifier for the current animation frame loop.
   * @type {Number} 
   */
  this.animationPointer = null;

  /**
   * @type {Boolean} 
   */
  this.isPaused = false;

  this.isStopped = false;

  /**
   * The array of animation callbacks.
   * @type {!Array.<Function>} 
   */
  this.arrCallbacks = [];

  /**
   * Starts the animation cycle.
   */
  this.startAnimation = function() {
    this.isStopped = false;
    this.animationPointer = window.requestAnimationFrame(this.draw.bind(this));
  };

  /**
   * Stops the animation cycle. 
   */
  this.stopAnimation = function() {
    window.cancelAnimationFrame(this.animationPointer);
    this.isStopped = true;
  };

  /**
   * Pauses the invocation of the animation functions each draw cycle. If set
   * to true, the animation functions will not be invoked. If set to false, 
   * the functions will be invoked.
   * @type {Boolean} 
   */
  this.pauseAnimation = function(boolPause) {
    this.isPaused = boolPause;
  };

  /**
   * Adds an animation function to the draw cycle.
   * @param {Function} 
   */
  this.addAnimation = function(callback) {
    if (this.arrCallbacks.indexOf(callback) == -1) {
      this.arrCallbacks.push(callback);
    }
  };

  /**
   * Removes an animation function from the draw cycle.
   * @param {Function} 
   */
  this.removeAnimation = function(callback) {
    var targetIndex = this.arrCallbacks.indexOf(callback);
    if (targetIndex > -1) {
      this.arrCallbacks.splice(targetIndex, 1);
    }
  };

  /**
   * Draws any registered animation functions (assuming they are not paused)
   * and then kicks off another animation cycle.
   * This is a 'private' method that you should not have to access directly.
   * @private 
   */
  this.draw = function() {
    if (!this.isPaused) {
      var i = 0, arrCallbacksLength = this.arrCallbacks.length;
      for (i = 0; i < arrCallbacksLength; i++) {
        this.arrCallbacks[i]();
      }
    }
    if (!this.isStopped) {
      this.startAnimation();
    }
  };
};