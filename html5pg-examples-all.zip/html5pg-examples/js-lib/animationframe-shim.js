console.log('Animation timing shim has been loaded and executed.');
