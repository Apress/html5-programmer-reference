// Include the modules needed to build the server.
var http = require('http');
var sys = require('sys');
var fs = require('fs');

// Use the http.createServer method to create a server listening on port 8030.
// The server will call the handleRequest method each time a request is
// received.
http.createServer(handleRequest).listen(8030);

/**
 * Handle an incoming request from the server. 
 * @param {Object} request The request headers.
 * @param {Object} resource A reference to the server resource that received
 *     the request.
 */
function handleRequest(request, resource) {
  // Incoming requests to our server will be to one of two URLs.
  // If the request is for /example3-5-events we should send our SSE.
  // If the request is for /example3-6.html, we should serve the example client.
  if (request.url == '/example3-5-events') {
    // Initialize an event stream.
    sendSSE(request, resource);
  } else if (request.url == '/example3-6.html'){
    // Send the client.
    resource.writeHead(200, {'Content-Type': 'text/html'});
    resource.write(fs.readFileSync('example3-6.html'));
    resource.end();
  }
}

/**
 * Initializes an event stream and starts sending an event every 5 seconds. 
 * @param {Object} request The 
 * @param {Object} resource
 */
function sendSSE(request, resource) {
  // Initialize the event stream.
  resource.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });

  // Send an event every 5 seconds.
  setInterval(function() {
    // Randomly generate either 0 or 1.
    var randNumber = Math.floor(Math.random() * 2);
    // If the random number is 1, set isChanged to true. Otherwise, set it to
    // false.
    var isChanged = (randNumber === 1) ? true : false;
    resource.write('data: ' + '{"isChanged":' + isChanged + '}\n\n');
  }, 5000);
}