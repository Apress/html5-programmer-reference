// Include the modules needed to build the server.
var WebSocketServer = require('websocket').server;
var http = require('http');
var currentConnection;

// Define the subprotocol name for the web socket connection.
var subProtocol = 'echo';

/**
 * Handles a request event on the web socket server. 
 * @param {Object} request
 */
function handleRequest(request) {
  currentConnection = request.accept(subProtocol, request.origin);
  currentConnection.on('message', handleMessage);
}

/**
 * Handles a message event on a socket connection.
 * @param {Object} message The message event object. 
 */
function handleMessage(message) {
  // Echo back whatever was received.
  if (message.type === 'utf8') {
    currentConnection.sendUTF(message.utf8Data);
  } else if (message.type === 'binary') {
    currentConnection.sendBytes(message.binaryData);
  }
}

// Create a simple server that always returns 404 (not found) to any request.
// (We're only going to use it to upgrade to the web socket protocol.)
var simpleServer = http.createServer(function(request, response) {
    response.writeHead(404);
    response.end();
});
simpleServer.listen(8080);

// Create a web socket server based on the simple server.
var socketServer = new WebSocketServer({
    httpServer: simpleServer,
    autoAcceptConnections: false
});

// Register the request event handler.
socketServer.on('request', handleRequest);
