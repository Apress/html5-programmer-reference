/**
 * Handles a message event from the main context.
 * @param {WorkerMessageEvent} event The message event. 
 */
function handleMessageEvent(event) {
  // Do something with the message.
  console.log('Worker received message:', event.data);

  // Send the message back to the main context.
  self.postMessage('Your message was received.');
}

// Register the message event handler.
self.addEventListener('message', handleMessageEvent);

// Dispatch 10 events to the host document.
var counter = 0;
var timer = setInterval(function() {
  counter++;
  self.postMessage('Message #' + counter);
  if (counter == 10) {
    // Stop the timer.
    clearInterval(timer);

    // Throw an error.
    throw new Error();
  }
}, 1000);
