/**
 * Detects support for various HTML5 features.
 * @constructor
 * @returns {Object.<boolean>} An object with properties for each feature, each
 *     set to true or false depending on support.
 */
function DetectHTML5Support() {
  var returnVal = {};

  // Test for HTML5 APIs on the window object.
  var apisToTest = ['EventSource', 'postMessage', 'sessionStorage',
      'localStorage', 'Worker', 'requestAnimationFrame',
      'cancelAnimationFrame', 'DeviceMotionEvent', 'DeviceOrientationEvent'];
  for (i = 0; i < apisToTest.length; i++) {
    var currApi = apisToTest[i];
    returnVal[currApi] = (window[currApi] != undefined);
  }

  // Test for HTML5 APIs on the navigator object.
  var apisToTest = ['geolocation'];
  for (i = 0; i < apisToTest.length; i++) {
    var currApi = apisToTest[i];
    returnVal[currApi] = (navigator[currApi] != undefined);
  }

  // Test for HTML5 APIs on the document object.
  var apisToTest = ['querySelector', 'querySelectorAll'];
  for (i = 0; i < apisToTest.length; i++) {
    var currApi = apisToTest[i];
    returnVal[currApi] = (document[currApi] != undefined);
  }

  // Test for suport for the new HTML5 elements.
  var unsupported = 'HTMLUnknownElement';
  var elementsToTest = ['article', 'aside', 'nav', 'footer', 'header',
      'section', 'figure', 'figcaption', 'main', 'bdi', 'data', 'mark',
      'ruby', 'rp', 'rt', 'time', 'wbr', 'dialog', 'details', 'summary',
      'datalist', 'meter', 'output', 'progress', 'audio', 'canvas', 'video'];
  for (i = 0; i < elementsToTest.length; i++) {
    var currItem = elementsToTest[i];
    var testEl = document.createElement(currItem);
    returnVal[currItem] = (testEl.toString().indexOf(unsupported) == -1);
    testEl = null;
  }

  // Test for support for new input properties that are booleans.
  var propsToTest = ['autofocus', 'draggable'];
  var inputEl = document.createElement('input');
  // For variety we'll use Array.forEach to run these tests instead of an
  // explicit for loop.
  propsToTest.forEach(function(currProp) {
    var testValue = true;
    inputEl.setAttribute(currProp, testValue);
    returnVal[currProp] = (inputEl[currProp] === testValue);
  }, this);

  // Test for support for new input properties that are strings.
  propsToTest = ['autocomplete', 'placeholder'];
  propsToTest.forEach(function(currProp) {
    var testValue = 'testval';
    inputEl.setAttribute(currProp, testValue);
    returnVal[currProp] = (inputEl[currProp] === testValue);
  }, this);
  inputEl = null;

  /**
   * Returns a sorted array of all features that were tested for.
   * @returns {Array.<string>} 
   */
  returnVal.getTests = function() {
    // Get all of the properties and methods we've added to returnVal and
    // sort them.
    var allPropsAndMethods = Object.keys(this).sort();

    // This list will contain all the properties and methods, but we only want
    // properties, so filter out the methods.
    var allTests = [];
    allPropsAndMethods.forEach(function(currItem) {
      if (typeof this[currItem] != 'function') {
        allTests.push(currItem);
      }
    }, this);

    return allTests;
  };

  /**
   * Returns an array consisting of all test results. Each result is an object
   * with the feature property set to the name of the test and the isSupported
   * property set to true or false, depending on the support for that feature.
   * @returns {Array.<Object>}
   */
  returnVal.getTestResults = function() {
    var tests = this.getTests();
    var allResults = [];
    tests.forEach(function(currTest) {
      var currResult = {
        feature: currTest,
        isSupported: this[currTest]
      };
      allResults.push(currResult);
    }, this);
    return allResults;
  };

  /**
   * Returns an array of test results for all failed tests. Each result is an
   * object as described in getResults.
   * @returns {Array.{Object}} 
   */
  returnVal.getFailedTestResults = function() {
    var tests = this.getTests();
    var failures = [];
    tests.forEach(function(currTest) {
      if (!this[currTest]) {
        var currResult = {
          feature: currTest,
          isSupported: this[currTest]
        };
        failures.push(currResult);
      }
    }, this);
    return failures;
  };

  // Return the object with all the results.
  return returnVal;
}