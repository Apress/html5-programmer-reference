/**
 * Creates a new game. Assumes that the required DOM elements are present.
 * @constructor 
 */
function MobiDex() {

  /**
   * Whether or not the game has been initialized.
   * @type {boolean}
   * @private 
   */
  this.isInitialized_ = false;
  
  /**
   * Reference to the 'gameover' DOM element.
   * @type {Element}
   * @private
   */
  this.domGameOver_ = document.getElementById('gameover');
  
  /**
   * Reference to the 'gamefield' DOM element.
   * @type {Element}
   * @private 
   */
  this.gameField_ = document.getElementById('game-field');
  
  /**
   * Reference to the ball DOM element. 
   * @type {Element}
   * @private
   */
  this.ball_ = document.getElementById('ball');
  
  /**
   * Reference to the 'remaining-balls' DOM element.
   * @type {Element}
   * @private 
   */
  this.remainingBalls_ = document.getElementById('remaining-balls');
  
  /**
   * The current coordinate of the 'ball'.
   * @type {Coordinate}
   * @private
   */
  this.currCoordinate_ = new Coordinate(0, 0);
  
  /**
   * The index of the obstacle that the ball is currently colliding with.
   * @type {number}
   * @private 
   */
  this.currentObstacleIndex_ = -1;
  
  /**
   * The index of the target that the ball is currently colliding with.
   * @type {number}
   * @private 
   */
  this.currentTargetIndex_ = -1;
  
  /**
   * Reference to the current obstacle during a collision event. Stored between
   * draw cycles to prevent firing multiple collisions.
   * @type {Coordinate}
   * @private
   */
  this.currObstacle_ = new Coordinate(0, 0);
  
  /**
   * Array of obstacle coordinates.
   * @type {Array.<Coordinate>}
   * @private 
   */
  this.arrObstacles_ = [];
  
  /**
   * Array of target coordinates.
   * @type {Array.<Coordinate>}
   * @private
   */
  this.arrTargets_ = [];
  
  /**
   * The number of targets that have been collected.
   * @type {number}
   * @private 
   */
  this.collectedTargets_ = 0;
  
  /**
   * The number of 'lives' remaining.
   * @type {number}
   * @private 
   */
  this.balls_ = 3;
  
  /**
   * The draw cycle object for the game.
   * @type {DrawCycle}
   * @private 
   */
  this.drawCycle_ = new DrawCycle();
  
  /**
   * The number of obstacles to draw on the game field.
   * @type {number}
   * @private 
   */
  this.numberOfObstacles_ = 10;
  
  /**
   * The number of targets to draw on the game field.
   * @type {number}
   * @private 
   */
  this.numberOfTargets_ = 10;
  
  
  /**
   * Start the game. Initializes data structures, draws the UI, and starts the
   * animation cycle. 
   */
  this.startGame = function() {
    // Reset the game variables.
    this.reset_();
  
    // Hide the game over message.
    this.domGameOver_.classList.add('hidden');
  
    // Draw a random game field.
    this.drawGameField_();
  
    if (!this.isInitialized_) {
      this.init_();
    }
  
    // Start the draw cycle.
    this.drawCycle_.startAnimation();
  };
  
  
  /**
   * Resets game variables to their base state.
   * @private 
   */
  this.reset_ = function() {
    this.balls_ = 3;
    this.arrObstacles_ = [];
    this.arrTargets_ = [];
    this.collectedTargets_ = 0;
    this.currCoordinate_ = new Coordinate(0, 0);
    this.currentObstacleIndex_ = -1;
    this.currentTargetIndex_ = -1;
  };
  
  
  /**
   * Initialze the game for the first time.
   * @private 
   */
  this.init_ = function() {  
    // Register the device orientation event handler on the window object.
    window.addEventListener('deviceorientation',
        this.handleDeviceOrientation_.bind(this),
        false);
  
    // Add the draw method to the draw cycle.
    this.drawCycle_.addAnimation(this.drawScreen_.bind(this));
  
    this.isInitialized_ = true;
  };
  
  
  /**
   * Initializes the obstacles and targets and draws the UI.
   * @private
   */
  this.drawGameField_ = function() {
    // Clear the game field.
    this.gameField_.innerHTML = '';
  
    // Fill up the obstacle and target arrays with random coordinates.
    this.generateCoords_(this.numberOfObstacles_, this.arrObstacles_);
    this.generateCoords_(this.numberOfTargets_, this.arrTargets_);
  
    // Create a div that can be used as a template for cloning.
    var templateDiv = document.createElement('div');
  
    // Add the obstacles to the playing field.
    this.arrObstacles_.forEach(function(currCoord) {
      var newObstacle = templateDiv.cloneNode();
      newObstacle.classList.add('obstacle');
      newObstacle.style.left = currCoord.x + 'px';
      newObstacle.style.top = currCoord.y + 'px';
      this.gameField_.appendChild(newObstacle);
    }, this);
  
    // Add the targets to the playing field.
    this.arrTargets_.forEach(function(currCoord, index) {
      var newTarget = templateDiv.cloneNode();
      newTarget.classList.add('target');
      newTarget.style.left = currCoord.x + 'px';
      newTarget.style.top = currCoord.y + 'px';
      this.gameField_.appendChild(newTarget);
      // Store a reference to the new element in the array, we will need it
      // later.
      currCoord.element = newTarget;
      this.arrTargets_.splice(index, 1, currCoord);
    }, this);
    
      // Update the lives displayed.
    this.updateRemainingBalls_();
  };
  
  
  /**
   * Handles a deviceorientation event from the window.
   * @param {DeviceOrientationEvent} event The device orientation event object.
   * @private
   */
  this.handleDeviceOrientation_ = function(event) {
    // Get the x and y positions and update the current coordiate with them.
    this.currCoordinate_.x = this.getOrd_(event.gamma, this.currCoordinate_.x);
    this.currCoordinate_.y = this.getOrd_(event.beta, this.currCoordinate_.y);
  
    // Check for collisions.
    this.currentObstacleIndex_ = this.checkCollision_(this.currCoordinate_, 10,
        this.arrObstacles_);
    this.currentTargetIndex_ = this.checkCollision_(this.currCoordinate_, 10,
        this.arrTargets_);
  };
  
  
  /**
   * Draws the screen for the game: positions the 'ball' and updates the number
   * of lives as necessary. Registered in the draw cycle.
   * @private
   */
  this.drawScreen_ = function() {
    // Move the "ball."
    this.ball_.style.top = this.currCoordinate_.y + 'px';
    this.ball_.style.left = this.currCoordinate_.x + 'px';
  
    // Check for obstacle collisisons.
    if (this.currentObstacleIndex_ > -1) {
      // Yes, there is a collision active. Check to see if it is a new
      // collision.
      var obstacle = this.arrObstacles_[this.currentObstacleIndex_];
      if ((this.currObstacle_.x != obstacle.x) &&
          (this.currObstacle_.y != obstacle.y)) {
        // It is a new collision.
        // Add the collision class to the game field.
        this.gameField_.classList.add('collision');
        // Store the current obstacle for the next check.
        this.currObstacle_ = obstacle;
        // A collision with an obstacle costs a life.
        this.balls_--;
        this.updateRemainingBalls_();
        // If we're out of lives, the game is over.
        if (this.balls_ <= 0) {
          this.gameOver_(false);
        }
      }
    } else {
      // There is no collision active.
      // Remove the collision class from the game field.
      this.gameField_.classList.remove('collision');
      // Clear the current obstacle stored in the this.
      this.currObstacle_ = new Coordinate(0, 0);
    }
  
    // Check for target collisions.
    if (this.currentTargetIndex_ > -1) {
      // A target has been hit! Get the reference to the DOM element.
      var hitEl = this.arrTargets_[this.currentTargetIndex_].element;
      // If the element is not hidden, we need to hide it.
      if (!hitEl.classList.contains('hidden')) {
        hitEl.classList.add('hidden');
        // Increment the collected targets counter.
        this.collectedTargets_++;
        if (this.collectedTargets_ >= this.arrTargets_.length) {
          this.gameOver_(true);
        }
      }
    }
  };
  
  
  /**
   * Updates the number of remaining balls displayed.
   * @private
   */
  this.updateRemainingBalls_ = function() {
    // Clear the current lives.
    this.remainingBalls_.innerHTML = '';
    // Create a template that we can clone and use multiple times.
    var lifeTemplate = document.createElement('div');
    lifeTemplate.classList.add('life');
    // Add an element for each life.
    for (var i = 0; i < this.balls_; i++) {
      var currLife = lifeTemplate.cloneNode();
      currLife.style.left = (i * 15) + 'px';
      this.remainingBalls_.appendChild(currLife);
    }
  };
  
  
  /**
   * Check to see if the specified coordinates collide with an existing set of
   * coordinates.
   * @param {Coordinate} coordinate The coordinate to check.
   * @param {number} sensitivity The sensitivity for a collision. If coordinates
   *     are within sensitivity distance of a target coordinate, a collision
   *     will be registered.
   * @param {Array.<Coordinate>} arrTargetCoords An array of target coordinates
   *     to check against. 
   * @return {number} The index of the member of the target coordinates array
   *     that is being hit, or -1 if no collision is detected.
   * @private
   */
  this.checkCollision_ = function(coordinate, sensitivity, arrTargetCoords) {
    // Loop through each target coordinate and compare the provided values.
    for (var i = 0; i < arrTargetCoords.length; i++) {
      var currObstacle = arrTargetCoords[i];
      var xcoll = false;
      var ycoll = false;
  
      // If the provided x coordinate is within range of the obstacle coordinate,
      // then there is an x collision.
      if (((currObstacle.x - sensitivity) < coordinate.x) &&
          (coordinate.x < (currObstacle.x + sensitivity))) {
        xcoll = true;
      }
    
      // If the provided y coordinate is within range of the obstacle cooridnate,
      // Then there is a y collision.
      if (((currObstacle.y - sensitivity) < coordinate.y) &&
          (coordinate.y < (currObstacle.y + sensitivity))) {
        ycoll = true;
      }
  
      // If there is both an x and a y collision, then return true.
      if (xcoll && ycoll) {
        return i;
      }
    }
    return -1;
  };
  
  
  /**
   * Gets an ordinate based on an Euler angle.
   * @param {number} angle The orientation angle that is inducing the change.
   * @param {number} ord The previous value of the ordinate.
   * @return {number} The new value of the ordinate.
   * @private
   */
  this.getOrd_ = function(angle, ord) {
    var delta = Math.round(angle - (angle * 0.3));
    var tempVal = ord + delta;
    if (tempVal > 0) {
      ord = Math.min(192, tempVal);
    } else {
      ord = 0;
    }
    return ord;
  };
  
  
  /**
   * Generates a set of random coordinates and adds them to the provided array.
   * Tries to avoid duplicating too closely any previously-generated
   *     coordinates.
   * @param {number} numberOfCoords The number of coordinates to generate.
   * @param {Array} targetArray The array to fill with the new coordinates.
   * @private
   */
  this.generateCoords_ = function(numberOfCoords, targetArray) {
    for (var i = 0; i < numberOfCoords; i++) {
      var newCoord = new Coordinate(this.getRandomIntegerBetween_(10, 190),
          this.getRandomIntegerBetween_(10, 190));
      while (this.checkCollision_(newCoord, 15, 
            this.arrObstacles_.concat(this.arrTargets_)) > -1) {
        newCoord.x = this.getRandomIntegerBetween_(10, 190);
        newCoord.y = this.getRandomIntegerBetween_(10, 190);
      }
      targetArray.push(newCoord);
    }
  };
  
  
  /**
   * Returns a random integer between the specified minimum and maximum values.
   * @param {number} min The lower boundary for the random number.
   * @param {number} max The upper boundary for the random number.
   * @return {number}
   * @private
   */
  this.getRandomIntegerBetween_ = function(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };
  
  
  /**
   * Ends the game.
   * @param {boolean} isWinner Whether the game was won or lost.
   * @private
   */
  this.gameOver_ = function(isWon) {
    this.drawCycle_.stopAnimation();
    if (isWon) {
      this.domGameOver_.classList.remove('looser');
      this.domGameOver_.classList.add('winner');
      this.domGameOver_.innerHTML = 'Winner!';
    } else {
      this.domGameOver_.classList.remove('winner');
      this.domGameOver_.classList.add('looser');
      this.domGameOver_.innerHTML = 'Try Again!';
    }
    this.domGameOver_.classList.remove('hidden');
  };
};

/**
 * Coordinate class.
 * @param {number} xOrd The x ordinate of the coordinate.
 * @param {number} yOrd The y ordinate of the coordinate.
 * @param {Element} element A reference to the DOM element for these
 *     coordinates.
 * @constructor 
 */
function Coordinate(xOrd, yOrd, element) {
  this.x = xOrd;
  this.y = yOrd;
  this.element = element;
}
