console.log('web storage shim has been loaded and executed.');
